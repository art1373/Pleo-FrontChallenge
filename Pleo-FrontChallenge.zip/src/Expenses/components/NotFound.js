import React from "react";

const NotFound = () => {
  return (
    <div>
      <img
        className="not-found"
        src={require("../../assets/Icons/404.gif")}
        alt="notFound"
      />
    </div>
  );
};

export default NotFound;
